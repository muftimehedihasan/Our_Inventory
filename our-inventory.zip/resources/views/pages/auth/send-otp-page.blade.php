@extends('layout.app')
@section('content')
    @include('components.auth.send-otp-form')
@endsection
